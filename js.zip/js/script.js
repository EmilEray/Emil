fetch("https://community-open-weather-map.p.rapidapi.com/forecast/daily?q=bishkek%2CKyrgyzstan&lat=42.87&lon=74.59&cnt=15&units=metric%20or%20imperial&lang=ru", {
  "method": "GET",
  "headers": {
    "x-rapidapi-key": "4613906626msh3ef3a52f788ce0fp1c01e0jsn96ef5dec1531",
    "x-rapidapi-host": "community-open-weather-map.p.rapidapi.com"
  }
})
.then(response => {
  console.log(response);
    return response.json()
  })
  .then(data =>{
  console.log(data)
  })
  .catch(err => {
  console.error(err);
  });